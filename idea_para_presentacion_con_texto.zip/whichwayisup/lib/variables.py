'''A very, very simple module for storing config.
Separated from the util module to avoid import loops.'''

class Variables:
  vdict = {}